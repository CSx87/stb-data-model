#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>

#include <stdio.h>
#include <stdlib.h>
#include<pthread.h>
#include<unistd.h>

//Thread ka kaam is to print the arg after every 1s
static void * thread_function(void * arg){
    char * input;
    input = (char *)arg;

    while(1){
        printf("%s\n",input);
        sleep(1);
    }

}


void thread_create(){
    pthread_t pthread1; //Declare
    static char * thread_input = "I am thread no.1"; //For inputs
    int rc = pthread_create(&pthread1,NULL,thread_function,thread_input);
    if(rc!=0)
        {
            printf("Error in opening thread");
            exit(0);
        }
}


int main(){
    thread_create();
    // printf("Main function is paused"); //if not paused then it will terminate so will its child thread
    // pause();

    while(1){
        printf("Main thread");
        sleep(1);
    }


}
